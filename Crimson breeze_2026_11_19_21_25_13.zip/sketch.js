let trafficData = null;
let routeData = null;
let currentStart = null;

// محدوده جغرافیایی گراف برای تبدیل دقیق به پیکسل
let bounds = { minLat: 51.51, maxLat: 51.53, minLon: -0.14, maxLon: -0.12 };
const PADDING = 30;

const scenarioSelect = document.getElementById("scenario-select");
const objectiveSelect = document.getElementById("objective-select");
const statsBody = document.getElementById("stats-body");

function setup() {
  const container = document.getElementById("canvas-container");
  const cnv = createCanvas(container.clientWidth, container.clientHeight);
  cnv.parent("canvas-container");

  scenarioSelect.addEventListener("change", () => {
    if (currentStart) fetchRoutes(currentStart.lat, currentStart.lon);
  });
  objectiveSelect.addEventListener("change", () => {
    if (currentStart) fetchRoutes(currentStart.lat, currentStart.lon);
  });

  initMapData();
}

function windowResized() {
  const container = document.getElementById("canvas-container");
  resizeCanvas(container.clientWidth, container.clientHeight);
}

// ---------------- تبدیل مختصات جغرافیایی <-> پیکسل ----------------

function computeBounds(layers) {
  let minLat = Infinity, maxLat = -Infinity;
  let minLon = Infinity, maxLon = -Infinity;

  for (const list of Object.values(layers)) {
    for (const item of list) {
      for (const [lat, lon] of item.coords) {
        if (lat < minLat) minLat = lat;
        if (lat > maxLat) maxLat = lat;
        if (lon < minLon) minLon = lon;
        if (lon > maxLon) maxLon = lon;
      }
    }
  }
  bounds = { minLat, maxLat, minLon, maxLon };
}

function getProjectionParams() {
  const midLatRad = ((bounds.minLat + bounds.maxLat) / 2) * (Math.PI / 180);
  const cosLat = Math.cos(midLatRad);

  const geoW = (bounds.maxLon - bounds.minLon) * cosLat;
  const geoH = bounds.maxLat - bounds.minLat;

  const availW = width - 2 * PADDING;
  const availH = height - 2 * PADDING;
  const scale = Math.min(availW / geoW, availH / geoH);

  const offsetX = (width - geoW * scale) / 2;
  const offsetY = (height - geoH * scale) / 2;

  return { cosLat, scale, offsetX, offsetY };
}

function latLonToXY(lat, lon) {
  const { cosLat, scale, offsetX, offsetY } = getProjectionParams();
  const x = offsetX + (lon - bounds.minLon) * cosLat * scale;
  const y = offsetY + (bounds.maxLat - lat) * scale;
  return { x, y };
}

function xyToLatLon(x, y) {
  const { cosLat, scale, offsetX, offsetY } = getProjectionParams();
  const lon = bounds.minLon + (x - offsetX) / (cosLat * scale);
  const lat = bounds.maxLat - (y - offsetY) / scale;
  return { lat, lon };
}

// ---------------- ارتباط با بک‌اند پایتون ----------------

async function initMapData() {
  const res = await fetch("/api/traffic");
  trafficData = await res.json();
  computeBounds(trafficData.layers);

  currentStart = {
    lat: trafficData.default_start.lat,
    lon: trafficData.default_start.lon,
  };
  await fetchRoutes(currentStart.lat, currentStart.lon);
}

async function fetchRoutes(lat, lon) {
  const scenario = scenarioSelect.value;
  const objective = objectiveSelect.value;
  const url = /api/route?lat=${lat}&lon=${lon}&scenario=${scenario}&objective=${objective};

  const res = await fetch(url);
  routeData = await res.json();
  currentStart = { lat: routeData.start.lat, lon: routeData.start.lon };
  renderStatsTable(routeData.routes);
}

function renderStatsTable(routes) {
  statsBody.innerHTML = "";
  for (const [algoName, info] of Object.entries(routes)) {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td><strong>${algoName}</strong></td>
      <td>${info.found ? "Found" : "No Path"}</td>
      <td>${info.total_distance_m ?? "-"}</td>
      <td>${info.total_time_s ?? "-"}</td>
      <td>${info.node_expansions}</td>
      <td>${info.max_frontier_size}</td>
      <td>${info.runtime_ms}</td>
    `;
    statsBody.appendChild(row);
  }
}
