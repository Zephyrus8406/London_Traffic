function drawPolyline(coords) {
  noFill();
  beginShape();
  for (const [lat, lon] of coords) {
    const pt = latLonToXY(lat, lon);
    vertex(pt.x, pt.y);
  }
  endShape();
}

function draw() {
  background(15, 23, 42);

  if (!trafficData) {
    fill(200);
    noStroke();
    textAlign(CENTER, CENTER);
    text("Loading London graph...", width / 2, height / 2);
    return;
  }

  const layers = trafficData.layers;

  // ۱. رسم شبکه خیابان‌های عادی در پس‌زمینه (در صورت وجود)
  if (layers.normal) {
    stroke(51, 65, 85);
    strokeWeight(1.5);
    layers.normal.forEach((item) => drawPolyline(item.coords));
  }

  // ۲. رسم لایه‌های ترافیک بر اساس چک‌باکس‌ها
  if (document.getElementById("chk-missing").checked) {
    stroke(100, 116, 139);
    strokeWeight(1.5);
    layers.missing.forEach((item) => drawPolyline(item.coords));
  }
  if (document.getElementById("chk-yellow").checked) {
    stroke(234, 179, 8);
    strokeWeight(2.5);
    layers.yellow.forEach((item) => drawPolyline(item.coords));
  }
  if (document.getElementById("chk-red").checked) {
    stroke(220, 38, 38);
    strokeWeight(3);
    layers.red.forEach((item) => drawPolyline(item.coords));
  }
  if (document.getElementById("chk-closed").checked) {
    stroke(0);
    strokeWeight(4);
    layers.closed.forEach((item) => drawPolyline(item.coords));
  }
  if (document.getElementById("chk-manual").checked) {
    stroke(244, 63, 94);
    strokeWeight(5);
    layers.manual_closed.forEach((item) => drawPolyline(item.coords));
  }

  // ۳. رسم مسیر ۴ الگوریتم
  if (routeData) {
    const drawRoute = (algoName, checkboxId, r, g, b, weight) => {
      const info = routeData.routes[algoName];
      if (!info !info.found !document.getElementById(checkboxId).checked) return;
      stroke(r, g, b);
      strokeWeight(weight);
      info.segments.forEach((seg) => drawPolyline(seg));
    };

    drawRoute("DFS", "chk-dfs", 251, 146, 60, 2.5);
    drawRoute("BFS", "chk-bfs", 192, 132, 252, 3.5);
    drawRoute("Greedy", "chk-greedy", 74, 222, 128, 4.5);
    drawRoute("A*", "chk-astar", 59, 130, 246, 5.5);

    // ۴. رسم مارکرهای مبدأ (سبز) و مقصد (قرمز)
    const startPt = latLonToXY(routeData.start.lat, routeData.start.lon);
    const goalPt = latLonToXY(routeData.goal.lat, routeData.goal.lon);

    stroke(255);
    strokeWeight(2);
    fill(34, 197, 94);
    circle(startPt.x, startPt.y, 14);

    fill(239, 68, 68);
    circle(goalPt.x, goalPt.y, 14);

    noStroke();
    fill(255);
    textSize(12);
    textAlign(LEFT, CENTER);
    text("START", startPt.x + 10, startPt.y);
    text("GOAL", goalPt.x + 10, goalPt.y);
  }
}

// ---------------- رویداد دابل‌کلیک در p5.js ----------------

function doubleClicked() {
  if (mouseX >= 0 && mouseX <= width && mouseY >= 0 && mouseY <= height) {
    const { lat, lon } = xyToLatLon(mouseX, mouseY);
    fetchRoutes(lat, lon);
  }
}
